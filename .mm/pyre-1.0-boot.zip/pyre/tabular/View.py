# -*- coding: utf-8 -*-
#
# michael a.g. aïvázis
# orthologue
# (c) 1998-2018 all rights reserved
#


class View:
    """
    The base class for table renderers
    """


# end of file

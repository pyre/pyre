# -*- coding: utf-8 -*-
#
# michael a.g. aïvázis
# orthologue
# (c) 1998-2018 all rights reserved
#


class Pivot:
    """
    The base class for reorganizing the information content of tables
    """


# end of file

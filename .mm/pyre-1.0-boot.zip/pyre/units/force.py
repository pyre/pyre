# -*- coding: utf-8 -*-
#
# michael a.g. aïvázis
# orthologue
# (c) 1998-2018 all rights reserved
#


from .SI import meter, second


gal = 0.01*meter/second**2


# end of file

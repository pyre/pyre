# -*- coding: utf-8 -*-
#
# michael a.g. aïvázis
# orthologue
# (c) 1998-2018 all rights reserved
#


"""
This package contains the implementation details of the two fundamental building blocks of
application behavior in pyre: components and protocols.

"""


# end of file
